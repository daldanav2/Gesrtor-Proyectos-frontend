import {Navbar, NavbarBrand, NavbarContent, NavbarItem, Link, Button, DropdownItem, DropdownTrigger, Dropdown, DropdownMenu} from "@nextui-org/react";
import {AcmeLogo} from "./AcmeLogo.jsx";

export default function DropMenu() {

  return (
    <h1>Hola</h1>
  );
}